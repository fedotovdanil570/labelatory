from .labelatory import create_app

create_app()